# 📊 Projeto Análise de Jogadores FIFA
## Inteligência Artificial 2024/2025 - Grupo 17

[![Python](https://img.shields.io/badge/Python-3.9+-blue.svg)](https://www.python.org/)
[![scikit-learn](https://img.shields.io/badge/scikit--learn-1.3+-orange.svg)](https://scikit-learn.org/)
[![pandas](https://img.shields.io/badge/pandas-2.0+-blue.svg)](https://pandas.pydata.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## 🎯 Objetivo do Projeto

Este projeto implementa três abordagens de machine learning para análise de dados de jogadores do FIFA:

1. **Classificação Supervisionada** - Previsão de potencial elevado usando Regressão Logística, Árvores de Decisão e SVM
2. **Clustering Não-Supervisionado** - Agrupamento de jogadores similares via K-Means
3. **Regras de Associação** - Descoberta de padrões entre atributos usando algoritmo Apriori

## 📊 Dataset

**Fonte:** FIFA Player Statistics  
**Arquivo:** `fifa_eda_stats.csv`  
**Características principais:**
- Atributos físicos: Age, Height, Weight, Strength
- Habilidades técnicas: Dribbling, Passing, Shooting, Ball Control
- Habilidades mentais: Positioning, Interceptions, Vision
- Ratings: Overall, Potential

## 🗂️ Estrutura do Projeto

```
IA25_P02_G-17/
├── 📄 README.md                    # Documentação principal do projeto
├── 📄 README_notebook1.md         # Documentação detalhada - Classificação
├── 📄 README_notebook2.md         # Documentação detalhada - Clustering
├── 📄 README_notebook3.md         # Documentação detalhada - Association Rules
├── 📊 notebook1.ipynb             # Implementação - Classificação
├── 📊 notebook2.ipynb             # Implementação - Clustering
├── 📊 notebook3.ipynb             # Implementação - Association Rules
├── 📋 IA92_Project02_Guide.pdf    # Especificações do projeto
└── 📈 fifa_eda_stats.csv          # Dataset FIFA
```

## 🛠️ Tecnologias Utilizadas

### Core Libraries
- **Python 3.9+** - Linguagem de programação principal
- **pandas** - Manipulação e análise de dados
- **numpy** - Computação numérica e arrays multidimensionais
- **matplotlib/seaborn** - Criação de visualizações

### Machine Learning
- **scikit-learn** - Framework de ML (classificação, clustering, preprocessing)
- **mlxtend** - Algoritmo Apriori e regras de associação

### Ambiente de Desenvolvimento
- **Jupyter Notebook** - Ambiente interativo para análise
- **VS Code** - Editor de código com suporte a Python
- **Git** - Controle de versão

## 🚀 Instalação e Configuração

### 1. Clonagem do Repositório
```bash
git clone https://github.com/ManoSanto/IA25_P02_G-17.git
cd IA25_P02_G-17
```

### 2. Criação do Ambiente Virtual
```bash
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
# ou
.venv\Scripts\activate     # Windows
```

### 3. Instalação das Dependências
```bash
pip install pandas numpy matplotlib seaborn scikit-learn mlxtend
```

### 4. Execução dos Notebooks
```bash
jupyter notebook
# ou
jupyter lab
```

## 📈 Algoritmos Implementados

### Notebook 1: Classificação Supervisionada
**Objetivo:** Prever se um jogador possui potencial ≥ 85

**Algoritmos:**
- **Regressão Logística** - Modelo linear probabilístico
- **Árvore de Decisão** - Classificador hierárquico
- **Support Vector Machine** - Classificador de margem máxima

**Métricas de avaliação:**
- Acurácia, Precision, Recall, F1-Score
- Matriz de confusão
- Curva ROC e AUC

### Notebook 2: Clustering Não-Supervisionado
**Objetivo:** Agrupar jogadores com características similares

**Algoritmo:**
- **K-Means** - Particionamento baseado em centroides

**Técnicas de validação:**
- Método do cotovelo para escolha de K
- Análise de silhueta
- Visualização com PCA/t-SNE

### Notebook 3: Regras de Associação
**Objetivo:** Descobrir padrões entre atributos dos jogadores

**Algoritmo:**
- **Apriori** - Mineração de itemsets frequentes

**Métricas:**
- Support: Frequência do padrão
- Confidence: Força da implicação
- Lift: Independência estatística

## 📊 Metodologia

### 1. Análise Exploratória (EDA)
- Estatísticas descritivas dos dados
- Distribuição de variáveis
- Correlações entre atributos
- Identificação de valores ausentes

### 2. Pré-processamento
- Limpeza de dados (missing values, outliers)
- Feature engineering
- Normalização/padronização
- Encoding de variáveis categóricas

### 3. Modelagem
- Implementação dos algoritmos
- Otimização de hiperparâmetros
- Validação cruzada
- Comparação de performance

### 4. Avaliação e Interpretação
- Métricas quantitativas
- Visualizações
- Análise de resultados
- Insights práticos

## 🎯 Resultados Esperados

### Classificação
- Comparação objetiva entre 3 algoritmos
- Identificação do modelo mais adequado
- Features mais importantes para predição

### Clustering
- Perfis distintos de jogadores (ex: atacantes técnicos, defensores físicos)
- Validação estatística dos grupos
- Interpretação prática dos clusters

### Association Rules
- Padrões como "bons dribladores tendem a ter boa aceleração"
- Regras acionáveis para scouting
- Combinações não-obvias de habilidades

## 📋 Validação e Métricas

### Estratégia de Validação
- **Holdout** - Divisão treino/teste (70/30)
- **Cross-validation** - Validação cruzada k-fold
- **Grid Search** - Otimização de hiperparâmetros

### Métricas por Tipo de Problema

#### Classificação
- **Acurácia:** Proporção de previsões corretas
- **Precision/Recall/F1:** Métricas balanceadas
- **AUC-ROC:** Capacidade discriminativa

#### Clustering
- **Silhouette Score:** Qualidade da separação dos clusters
- **Inertia:** Soma dos quadrados das distâncias intra-cluster
- **Calinski-Harabasz:** Razão entre soma de dispersões

#### Association Rules
- **Support:** Proporção de transações contendo o itemset
- **Confidence:** Probabilidade condicional
- **Lift:** Força da associação

## 👥 Equipe

**Grupo 17 - IA 2024/2025**
- Desenvolvimento colaborativo
- Revisão de código entre pares
- Validação cruzada de resultados

## 📚 Referências

- [Scikit-learn User Guide](https://scikit-learn.org/stable/user_guide.html)
- [MLxtend Documentation](https://rasbt.github.io/mlxtend/)
- [FIFA Dataset - Kaggle](https://www.kaggle.com/datasets/stefanoleone992/fifa-22-complete-player-dataset)
- [Hands-On Machine Learning - Aurélien Géron](https://www.oreilly.com/library/view/hands-on-machine-learning/9781492032632/)

## 📄 Licença

Este projeto está licenciado sob a MIT License - veja o arquivo [LICENSE](LICENSE) para detalhes.

---

**🏫 Disciplina:** Inteligência Artificial  
**📅 Ano:** 2024/2025  
**👥 Grupo:** 17  
**🎯 Tema:** Machine Learning aplicado à análise de dados FIFA