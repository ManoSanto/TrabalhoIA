# 📊 Notebook 2: Clustering K-Means FIFA
## Agrupamento Não-Supervisionado de Jogadores

## 🎯 Objetivo

Este notebook implementa clustering não-supervisionado usando o algoritmo K-Means para agrupar jogadores do FIFA com características similares, identificando perfis distintos de jogadores automaticamente.

## 📋 Algoritmo Implementado

### K-Means Clustering
- **Tipo:** Algoritmo de particionamento baseado em centroides
- **Objetivo:** Minimizar a soma dos quadrados das distâncias intra-cluster
- **Funcionamento:** Atribui cada ponto ao centroide mais próximo e recalcula centroides iterativamente

### Características do Algoritmo
- **Não-supervisionado:** Não requer labels pré-definidos
- **Iterativo:** Convergência baseada em critério de parada
- **Determinístico:** Resultados reproduzíveis com mesma semente
- **Escalável:** Eficiente para grandes datasets

## 🔄 Fluxo de Trabalho Detalhado

### 1. Instalação e Importações
```python
# Instala bibliotecas necessárias
%pip install pandas numpy matplotlib seaborn scikit-learn -q

# Importa bibliotecas para manipulação de dados
import pandas as pd
import numpy as np

# Importa bibliotecas para visualização
import matplotlib.pyplot as plt
import seaborn as sns

# Importa algoritmo K-Means
from sklearn.cluster import KMeans

# Importa pré-processamento
from sklearn.preprocessing import StandardScaler

# Importa métricas de avaliação
from sklearn.metrics import silhouette_score

# Importa PCA para visualização
from sklearn.decomposition import PCA
```

### 2. Carregamento dos Dados
```python
# Carrega dataset FIFA
df = pd.read_csv('fifa_eda_stats.csv')

# Exibe informações básicas do dataset
print(f"Dataset carregado: {df.shape[0]} linhas, {df.shape[1]} colunas")
print(df.head())
```

### 3. Seleção de Features
```python
# Define features relevantes para clustering
features = ['Age', 'Overall', 'Potential', 'Dribbling', 'Acceleration', 'Strength']

# Remove linhas com valores ausentes
df_cluster = df.dropna(subset=features).copy()

# Exibe estatísticas das features selecionadas
print(f"Amostras para clustering: {len(df_cluster)}")
print(df_cluster[features].describe())
```

### 4. Pré-processamento - Padronização
```python
# Inicializa StandardScaler
scaler = StandardScaler()

# Aplica padronização aos dados
X_scaled = scaler.fit_transform(df_cluster[features])

# Verifica resultado da padronização
print("Dados padronizados:")
print(f"Média: {X_scaled.mean(axis=0).round(3)}")
print(f"Desvio padrão: {X_scaled.std(axis=0).round(3)}")
```

### 5. Determinação do Número Ótimo de Clusters

#### Método do Cotovelo (Elbow Method)
```python
# Testa diferentes valores de K
inertia = []
K_range = range(1, 11)

for k in K_range:
    kmeans = KMeans(n_clusters=k, random_state=42, n_init='auto')
    kmeans.fit(X_scaled)
    inertia.append(kmeans.inertia_)

# Plota gráfico do cotovelo
plt.figure(figsize=(8, 5))
plt.plot(K_range, inertia, marker='o', color='blue', linewidth=2)
plt.xlabel('Número de Clusters (K)')
plt.ylabel('Inércia (Within-Cluster Sum of Squares)')
plt.title('Método do Cotovelo - Escolha de K')
plt.grid(True, alpha=0.3)
plt.show()
```

#### Análise de Silhueta
```python
# Calcula silhouette scores para diferentes K
silhouette_scores = []

for k in range(2, 11):
    kmeans = KMeans(n_clusters=k, random_state=42, n_init='auto')
    labels = kmeans.fit_predict(X_scaled)
    score = silhouette_score(X_scaled, labels)
    silhouette_scores.append(score)

# Plota silhouette scores
plt.figure(figsize=(8, 5))
plt.plot(range(2, 11), silhouette_scores, marker='o', color='green', linewidth=2)
plt.xlabel('Número de Clusters (K)')
plt.ylabel('Silhouette Score')
plt.title('Análise de Silhueta - Qualidade dos Clusters')
plt.grid(True, alpha=0.3)
plt.show()
```

### 6. Aplicação do K-Means
```python
# Define número ótimo de clusters baseado na análise
K_optimo = 4

# Inicializa e treina modelo K-Means
kmeans_final = KMeans(
    n_clusters=K_optimo,
    random_state=42,
    n_init='auto',
    max_iter=300
)

# Aplica clustering e obtém labels
df_cluster['Cluster'] = kmeans_final.fit_predict(X_scaled)

# Exibe distribuição dos clusters
print("Distribuição dos jogadores por cluster:")
print(df_cluster['Cluster'].value_counts().sort_index())
```

### 7. Análise dos Clusters
```python
# Calcula estatísticas descritivas por cluster
cluster_summary = df_cluster.groupby('Cluster')[features].agg(['mean', 'std', 'min', 'max'])

print("Resumo estatístico por cluster:")
print(cluster_summary)

# Identifica centroides dos clusters
centroids = kmeans_final.cluster_centers_
print("Centroides dos clusters (escala padronizada):")
print(centroids)
```

### 8. Interpretação dos Clusters
```python
# Analisa características distintivas de cada cluster
for cluster in range(K_optimo):
    cluster_data = df_cluster[df_cluster['Cluster'] == cluster]
    print(f"\nCluster {cluster}:")
    print(f"  - Tamanho: {len(cluster_data)} jogadores")
    print(f"  - Idade média: {cluster_data['Age'].mean():.1f} anos")
    print(f"  - Overall médio: {cluster_data['Overall'].mean():.1f}")
    print(f"  - Potencial médio: {cluster_data['Potential'].mean():.1f}")

# Atribui nomes descritivos aos clusters
cluster_names = {
    0: "Jovens Talentosos",
    1: "Veteranos Experientes",
    2: "Atacantes Técnicos",
    3: "Defensores Físicos"
}
```

## 📊 Métricas de Avaliação

### Silhouette Score
- **Fórmula:** (b - a) / max(a, b)
- **Onde:**
  - a = distância média intra-cluster
  - b = distância média para o cluster mais próximo
- **Interpretação:**
  - > 0.7: Clusters muito bem separados
  - 0.5-0.7: Clusters razoavelmente separados
  - 0.25-0.5: Clusters sobrepostos
  - < 0.25: Clusters mal definidos

### Inércia (Within-Cluster Sum of Squares)
- **Fórmula:** Σ Σ ||x - μ_k||² para todos os pontos x no cluster k
- **Interpretação:** Quanto menor, melhor (clusters mais coesos)
- **Limitação:** Decresce monotonicamente com K

### Calinski-Harabasz Index
- **Fórmula:** (B / (K-1)) / (W / (N-K))
- **Onde:**
  - B = soma dos quadrados entre clusters
  - W = soma dos quadrados intra-cluster
- **Interpretação:** Quanto maior, melhor

## 📈 Visualizações

### Gráfico do Cotovelo
```python
plt.figure(figsize=(10, 6))
plt.plot(K_range, inertia, 'bo-', linewidth=2, markersize=8)
plt.xlabel('Número de Clusters (K)', fontsize=12)
plt.ylabel('Inércia', fontsize=12)
plt.title('Método do Cotovelo', fontsize=14)
plt.grid(True, alpha=0.3)
plt.axvline(x=K_optimo, color='red', linestyle='--', label=f'K ótimo = {K_optimo}')
plt.legend()
plt.show()
```

### Visualização 2D com PCA
```python
# Reduz dimensionalidade para visualização
pca = PCA(n_components=2, random_state=42)
X_pca = pca.fit_transform(X_scaled)

# Plota clusters
plt.figure(figsize=(12, 8))
colors = ['red', 'blue', 'green', 'orange', 'purple', 'brown', 'pink', 'gray']

for cluster in range(K_optimo):
    mask = df_cluster['Cluster'] == cluster
    plt.scatter(X_pca[mask, 0], X_pca[mask, 1],
               c=colors[cluster],
               label=f'{cluster_names.get(cluster, f"Cluster {cluster}")}',
               alpha=0.7,
               s=50)

# Plota centroides
centroids_pca = pca.transform(kmeans_final.cluster_centers_)
plt.scatter(centroids_pca[:, 0], centroids_pca[:, 1],
           c='black', marker='x', s=200, linewidth=3,
           label='Centroides')

plt.xlabel(f'Componente Principal 1 ({pca.explained_variance_ratio_[0]:.1%} variância)', fontsize=12)
plt.ylabel(f'Componente Principal 2 ({pca.explained_variance_ratio_[1]:.1%} variância)', fontsize=12)
plt.title('Clusters de Jogadores FIFA - Visualização PCA', fontsize=14)
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()
```

### Radar Chart por Cluster
```python
# Cria radar chart para comparar clusters
def create_radar_chart(data, labels, title):
    angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False).tolist()
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(projection='polar'))

    for cluster in range(len(data)):
        values = data[cluster].tolist()
        values += values[:1]
        ax.plot(angles, values, 'o-', linewidth=2, label=f'Cluster {cluster}')
        ax.fill(angles, values, alpha=0.25)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels)
    ax.set_title(title, size=16, fontweight='bold', pad=20)
    ax.legend(loc='upper right', bbox_to_anchor=(1.2, 1.0))
    ax.grid(True)

    plt.show()

# Dados para radar chart
cluster_means = df_cluster.groupby('Cluster')[features].mean()
radar_data = cluster_means.values
radar_labels = features

create_radar_chart(radar_data, radar_labels, 'Perfil dos Clusters')
```

## 🛠️ Otimização de Hiperparâmetros

### Grid Search para K-Means
```python
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import make_scorer

# Define função de scoring customizada
def custom_silhouette_scorer(estimator, X):
    labels = estimator.fit_predict(X)
    return silhouette_score(X, labels)

# Grid search (limitado pois K-Means não tem muitos parâmetros)
param_grid = {
    'n_clusters': [3, 4, 5, 6],
    'init': ['k-means++', 'random'],
    'n_init': [10, 20, 30]
}

# Nota: GridSearchCV não é ideal para K-Means pois não tem y
# Melhor usar loop manual para diferentes configurações
```

### Comparação de Inicializações
```python
# Testa diferentes métodos de inicialização
init_methods = ['k-means++', 'random']
results = {}

for init_method in init_methods:
    kmeans_test = KMeans(n_clusters=K_optimo, init=init_method,
                         n_init=20, random_state=42)
    labels = kmeans_test.fit_predict(X_scaled)
    sil_score = silhouette_score(X_scaled, labels)
    results[init_method] = sil_score

print("Comparação de métodos de inicialização:")
for method, score in results.items():
    print(f"{method}: {score:.3f}")
```

## 🎯 Interpretação Prática

### Perfis de Jogadores Identificados

#### Cluster 0: Jovens Talentosos
- **Características:** Idade baixa, potencial elevado, overall médio
- **Perfil:** Jogadores em desenvolvimento com grande margem de crescimento
- **Aplicações:** Scouting de jovens, investimento em formação

#### Cluster 1: Veteranos Experientes
- **Características:** Idade elevada, overall alto, potencial limitado
- **Perfil:** Jogadores maduros com experiência consolidada
- **Aplicações:** Liderança técnica, experiência em competições

#### Cluster 2: Atacantes Técnicos
- **Características:** Alto drible, aceleração, controle de bola
- **Perfil:** Jogadores ofensivos com habilidades técnicas refinadas
- **Aplicações:** Criação de jogadas, finalização

#### Cluster 3: Defensores Físicos
- **Características:** Alta força, interceptações, velocidade moderada
- **Perfil:** Jogadores defensivos com presença física
- **Aplicações:** Marcação, disputas aéreas

## 🔄 Comparação com Outros Algoritmos

### DBSCAN
```python
from sklearn.cluster import DBSCAN

# DBSCAN não requer especificar K
dbscan = DBSCAN(eps=0.8, min_samples=10)
dbscan_labels = dbscan.fit_predict(X_scaled)

# Avalia resultado
n_clusters_dbscan = len(set(dbscan_labels)) - (1 if -1 in dbscan_labels else 0)
n_noise = list(dbscan_labels).count(-1)

print(f"DBSCAN encontrou {n_clusters_dbscan} clusters e {n_noise} pontos de ruído")
```

### Gaussian Mixture Models (GMM)
```python
from sklearn.mixture import GaussianMixture

# GMM assume distribuição gaussiana
gmm = GaussianMixture(n_components=K_optimo, random_state=42)
gmm_labels = gmm.fit_predict(X_scaled)

# Compara log-likelihood
print(f"GMM Log-Likelihood: {gmm.score(X_scaled):.3f}")
```

## 🎯 Aplicações no Futebol

### Scouting e Contratações
- **Identificação de perfis faltantes** no elenco
- **Comparação com jogadores similares** já no clube
- **Avaliação de potencial** baseada em clusters

### Desenvolvimento de Jogadores
- **Treinos personalizados** por perfil identificado
- **Foco em habilidades específicas** de cada cluster
- **Acompanhamento de progresso** dentro do perfil

### Análise Tática
- **Composição ideal de elenco** com diferentes perfis
- **Estratégias de substituição** baseadas em clusters
- **Análise de força relativa** entre times

## 📝 Limitações e Considerações

### Limitações do K-Means
- **Assunção de clusters esféricos** de tamanho similar
- **Sensível a outliers** e inicialização
- **Não hierárquico** - não captura estrutura aninhada
- **Requer especificação de K** a priori

### Melhorias Possíveis
- **Feature engineering** mais sofisticado
- **Seleção de features** baseada em importância
- **Algoritmos alternativos** para clusters não-esféricos
- **Validação externa** com especialistas

---

**Arquivo:** `notebook2.ipynb`  
**Tópico:** Clustering Não-Supervisionado  
**Algoritmo:** K-Means  
**Dataset:** FIFA Player Statistics  
**Grupo:** 17 - IA 2024/2025