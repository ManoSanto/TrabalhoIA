# 📊 Notebook 1: Classificação FIFA
## Previsão de Potencial Elevado de Jogadores

## 🎯 Objetivo

Este notebook implementa e compara 3 algoritmos de classificação supervisionada para prever se um jogador do FIFA possui potencial elevado (≥ 85) baseado em suas características atuais.

## 📋 Algoritmos Implementados

### 1. Regressão Logística
- Modelo linear que usa função sigmoide para classificação binária
- Calcula probabilidade de pertencer à classe positiva
- Eficiente e interpretable para problemas de classificação

### 2. Árvore de Decisão
- Algoritmo que cria regras hierárquicas de decisão
- Divide dados baseado em features que maximizam separação
- Fácil de interpretar e visualizar

### 3. Support Vector Machine (SVM)
- Encontra hiperplano que maximiza margem entre classes
- Usa kernel trick para dados não-linearmente separáveis
- Robusto e eficaz em espaços de alta dimensionalidade

## 🔄 Fluxo de Trabalho Detalhado

### 1. Instalação e Importações
```python
# Instala bibliotecas necessárias via pip
%pip install pandas numpy matplotlib seaborn scikit-learn -q

# Importa pandas para manipulação de dados
import pandas as pd

# Importa numpy para operações numéricas
import numpy as np

# Importa matplotlib para criação de gráficos
import matplotlib.pyplot as plt

# Importa seaborn para visualizações estatísticas
import seaborn as sns

# Importa algoritmo de Regressão Logística
from sklearn.linear_model import LogisticRegression

# Importa algoritmo de Árvore de Decisão
from sklearn.tree import DecisionTreeClassifier

# Importa algoritmo SVM
from sklearn.svm import SVC

# Importa função para dividir dados em treino/teste
from sklearn.model_selection import train_test_split

# Importa classe para padronização de features
from sklearn.preprocessing import StandardScaler

# Importa métricas de avaliação
from sklearn.metrics import accuracy_score, classification_report
```

### 2. Carregamento dos Dados
```python
# Carrega dataset FIFA do arquivo CSV
df = pd.read_csv('fifa_eda_stats.csv')

# Exibe dimensões do dataset
print(f"Dataset carregado: {df.shape[0]} linhas, {df.shape[1]} colunas")

# Exibe primeiras 5 linhas do dataset
print(df.head())
```

### 3. Preparação dos Dados
```python
# Define lista de features relevantes para classificação
features = ['Age', 'Overall', 'Potential', 'Dribbling', 'Passing', 'Shooting']

# Remove linhas com valores ausentes nas features selecionadas
df_clean = df.dropna(subset=features).copy()

# Cria variável target binária (1 se Potential >= 85, 0 caso contrário)
df_clean['High_Potential'] = (df_clean['Potential'] >= 85).astype(int)

# Separa features (X) da variável target (y)
X = df_clean[features]
y = df_clean['High_Potential']

# Exibe informações sobre dados preparados
print(f"Dados preparados: {len(X)} amostras, {len(features)} features")
print(f"Distribuição da classe target: {y.value_counts().to_dict()}")
```

### 4. Divisão Treino/Teste
```python
# Divide dados em conjuntos de treino e teste
# test_size=0.3 significa 30% para teste, 70% para treino
# random_state=42 garante reprodutibilidade
# stratify=y mantém proporção de classes em ambos os conjuntos
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.3,
    random_state=42,
    stratify=y
)

# Exibe tamanhos dos conjuntos
print(f"Conjunto de treino: {len(X_train)} amostras")
print(f"Conjunto de teste: {len(X_test)} amostras")
```

### 5. Pré-processamento - Padronização
```python
# Inicializa objeto StandardScaler
scaler = StandardScaler()

# Ajusta scaler aos dados de treino e transforma
# fit_transform calcula média/desvio e aplica transformação
X_train_scaled = scaler.fit_transform(X_train)

# Aplica mesma transformação aos dados de teste
# transform usa parâmetros calculados no fit_transform anterior
X_test_scaled = scaler.transform(X_test)

# Verifica se padronização foi aplicada corretamente
print("Dados padronizados - média aproximada:", X_train_scaled.mean().round(3))
print("Dados padronizados - desvio aproximado:", X_train_scaled.std().round(3))
```

### 6. Treinamento dos Modelos
```python
# Inicializa modelo de Regressão Logística com semente aleatória
model_lr = LogisticRegression(random_state=42)

# Inicializa modelo de Árvore de Decisão com semente aleatória
model_dt = DecisionTreeClassifier(random_state=42)

# Inicializa modelo SVM com semente aleatória
model_svm = SVC(random_state=42)

# Treina Regressão Logística nos dados de treino
model_lr.fit(X_train_scaled, y_train)

# Treina Árvore de Decisão nos dados de treino
model_dt.fit(X_train_scaled, y_train)

# Treina SVM nos dados de treino
model_svm.fit(X_train_scaled, y_train)

print("Todos os modelos foram treinados com sucesso")
```

### 7. Geração de Previsões
```python
# Gera previsões com Regressão Logística nos dados de teste
predictions_lr = model_lr.predict(X_test_scaled)

# Gera previsões com Árvore de Decisão nos dados de teste
predictions_dt = model_dt.predict(X_test_scaled)

# Gera previsões com SVM nos dados de teste
predictions_svm = model_svm.predict(X_test_scaled)

print("Previsões geradas para todos os modelos")
```

### 8. Avaliação dos Modelos
```python
# Calcula acurácia da Regressão Logística
accuracy_lr = accuracy_score(y_test, predictions_lr)

# Calcula acurácia da Árvore de Decisão
accuracy_dt = accuracy_score(y_test, predictions_dt)

# Calcula acurácia do SVM
accuracy_svm = accuracy_score(y_test, predictions_svm)

# Exibe resultados de acurácia
print(f"Regressão Logística - Acurácia: {accuracy_lr:.4f}")
print(f"Árvore de Decisão - Acurácia: {accuracy_dt:.4f}")
print(f"SVM - Acurácia: {accuracy_svm:.4f}")
```

### 9. Relatórios de Classificação Detalhados
```python
# Gera relatório completo para Regressão Logística
print("=== RELATÓRIO REGRESSÃO LOGÍSTICA ===")
print(classification_report(y_test, predictions_lr))

# Gera relatório completo para Árvore de Decisão
print("=== RELATÓRIO ÁRVORE DE DECISÃO ===")
print(classification_report(y_test, predictions_dt))

# Gera relatório completo para SVM
print("=== RELATÓRIO SVM ===")
print(classification_report(y_test, predictions_svm))
```

## 📊 Métricas de Avaliação

### Matriz de Confusão
```
                Previsto
                Classe 0    Classe 1
Real  Classe 0    TN          FP
Real  Classe 1    FN          TP
```

Onde:
- **TN (True Negative):** Previsão correta de classe negativa
- **FP (False Positive):** Previsão incorreta de classe positiva
- **FN (False Negative):** Previsão incorreta de classe negativa
- **TP (True Positive):** Previsão correta de classe positiva

### Métricas Calculadas
- **Precision:** TP / (TP + FP) - Proporção de previsões positivas corretas
- **Recall:** TP / (TP + FN) - Proporção de positivos reais identificados
- **F1-Score:** Média harmônica entre precision e recall
- **Support:** Número de ocorrências reais de cada classe

## 📈 Visualizações

### Curva ROC
```python
# Importa funções para curva ROC
from sklearn.metrics import roc_curve, auc

# Calcula probabilidades para Regressão Logística
proba_lr = model_lr.predict_proba(X_test_scaled)[:, 1]

# Calcula probabilidades para Árvore de Decisão
proba_dt = model_dt.predict_proba(X_test_scaled)[:, 1]

# Calcula probabilidades para SVM (requer probability=True no modelo)
# model_svm_prob = SVC(random_state=42, probability=True)
# model_svm_prob.fit(X_train_scaled, y_train)
# proba_svm = model_svm_prob.predict_proba(X_test_scaled)[:, 1]

# Calcula pontos da curva ROC para LR
fpr_lr, tpr_lr, _ = roc_curve(y_test, proba_lr)

# Calcula pontos da curva ROC para DT
fpr_dt, tpr_dt, _ = roc_curve(y_test, proba_dt)

# Calcula AUC para LR
auc_lr = auc(fpr_lr, tpr_lr)

# Calcula AUC para DT
auc_dt = auc(fpr_dt, tpr_dt)

# Plota curvas ROC
plt.figure(figsize=(8, 6))
plt.plot(fpr_lr, tpr_lr, label=f'LR (AUC = {auc_lr:.3f})')
plt.plot(fpr_dt, tpr_dt, label=f'DT (AUC = {auc_dt:.3f})')
plt.plot([0, 1], [0, 1], 'k--', label='Aleatório')
plt.xlabel('Taxa de Falsos Positivos')
plt.ylabel('Taxa de Verdadeiros Positivos')
plt.title('Curvas ROC - Comparação de Modelos')
plt.legend()
plt.grid(True)
plt.show()
```

### Matriz de Confusão Visual
```python
# Importa ferramentas para matriz de confusão
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

# Cria matriz de confusão para Regressão Logística
cm_lr = confusion_matrix(y_test, predictions_lr)

# Cria visualização da matriz
disp_lr = ConfusionMatrixDisplay(confusion_matrix=cm_lr)
disp_lr.plot(cmap='Blues')
plt.title('Matriz de Confusão - Regressão Logística')
plt.show()
```

### Importância de Features (Árvore de Decisão)
```python
# Verifica se modelo tem atributo feature_importances_
if hasattr(model_dt, 'feature_importances_'):
    # Obtém importância das features
    importances = model_dt.feature_importances_

    # Cria gráfico de barras
    plt.figure(figsize=(10, 6))
    plt.barh(features, importances)
    plt.xlabel('Importância')
    plt.ylabel('Features')
    plt.title('Importância das Features - Árvore de Decisão')
    plt.grid(True, alpha=0.3)
    plt.show()
```

## 🛠️ Otimização de Hiperparâmetros

### Grid Search para Regressão Logística
```python
# Importa GridSearchCV
from sklearn.model_selection import GridSearchCV

# Define grade de parâmetros para testar
param_grid_lr = {
    'C': [0.1, 1, 10, 100],              # Parâmetro de regularização
    'penalty': ['l1', 'l2'],              # Tipo de regularização
    'solver': ['liblinear', 'saga']       # Algoritmo solucionador
}

# Inicializa GridSearchCV
grid_search_lr = GridSearchCV(
    LogisticRegression(random_state=42),  # Modelo base
    param_grid_lr,                        # Grade de parâmetros
    cv=5,                                 # 5-fold cross-validation
    scoring='accuracy',                   # Métrica de avaliação
    n_jobs=-1                            # Usa todos os cores disponíveis
)

# Executa busca em grade
grid_search_lr.fit(X_train_scaled, y_train)

# Exibe melhores parâmetros e score
print("Melhores parâmetros encontrados:")
print(grid_search_lr.best_params_)
print(f"Melhor score de validação cruzada: {grid_search_lr.best_score_:.4f}")
```

## 🎯 Interpretação Prática

### Comparação de Performance
- **Regressão Logística:** Boa baseline, rápida, interpretable
- **Árvore de Decisão:** Interpretable, captura não-linearidades, pode overfit
- **SVM:** Geralmente melhor performance, menos interpretable

### Aplicações no Futebol
- **Scouting:** Identificar jovens com potencial elevado
- **Contratações:** Apoiar decisões de transferências
- **Desenvolvimento:** Guiar programas de treinamento

---

**Arquivo:** `notebook1.ipynb`  
**Tópico:** Classificação Supervisionada  
**Algoritmos:** Regressão Logística, Árvore de Decisão, SVM  
**Dataset:** FIFA Player Statistics  
**Grupo:** 17 - IA 2024/2025</content>
<parameter name="filePath">/Users/joaopeixoto/Projetos/IA25_P02_G-17/README_notebook1.md